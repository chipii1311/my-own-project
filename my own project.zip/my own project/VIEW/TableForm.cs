﻿using my_own_project.DesignForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace my_own_project.VIEW
{
    public partial class TableForm : SampleView
    {
        public TableForm()
        {
            InitializeComponent();
        }
    }
}
